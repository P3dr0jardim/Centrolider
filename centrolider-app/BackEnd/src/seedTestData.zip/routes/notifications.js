const express = require('express');
const router  = express.Router();
const auth    = require('../middleware/auth');
const ctrl    = require('../controllers/notificationsController');

router.get('/', auth, ctrl.getNotifications);

module.exports = router;
